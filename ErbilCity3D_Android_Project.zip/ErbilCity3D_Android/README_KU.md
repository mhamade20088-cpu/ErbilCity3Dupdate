# Erbil City 3D — Android Project

## چۆن APK دروست بکەیت؟
1. Android Studio دابەزێنە و پڕۆژەکە بکەرەوە (Open).
2. فولدەر `ErbilCity3D_Android` هەڵبژێرە.
3. چاوەڕێ بکە Gradle Sync تەواو ببێت.
4. لە منو: **Build → Build APK(s)**.
5. APK لە `app/build/outputs/apk/debug/app-debug.apk` دەردەچێت.


## تێبینی
- یارییەکە لە WebView و Three.js بەکار دەهێنێت.
- بۆ بارکردنی Three.js و فۆنت، لە کاتی یاری پێویستی بە ئینتەرنێت هەیە.
- ئەمە build-ready Android Studio project ـە؛ لەم ژینگەیەدا Android SDK/Gradle نییە بۆ کۆمپایلکردنی APK ڕاستەوخۆ.
